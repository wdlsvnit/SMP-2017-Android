#include<cs50.h>
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<ctype.h>
int main(int argc, string argv[])
{  if(argc==2)
    {int k = atoi(argv[1]);
    printf("plaintext:");
    string s=get_string();
      int n=strlen(s);
printf("ciphertext: ");
  for(int i=0;i<n;i++)
   {
      if(s[i]>='a' && s[i]<='z')
      {
          s[i]=(((s[i]-97)+k)%26)+97;
      }
      else if(s[i]>='A' && s[i]<='Z')
      {
        s[i]=(((s[i]-65)+k)%26)+65;
      }
      printf("%c",s[i]);
} printf("\n");
return 0;
}
else  if (argc!=2)
{printf("Usage:/home/cs50/pset2/ceasar<key>\n");
return 1;}

          }  
      
      

    
