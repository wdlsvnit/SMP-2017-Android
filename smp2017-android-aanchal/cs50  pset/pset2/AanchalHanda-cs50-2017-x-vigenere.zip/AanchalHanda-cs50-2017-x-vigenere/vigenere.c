#include<stdio.h>
#include<cs50.h>
#include<string.h>
#include<ctype.h>
int con(int a,string k);
int main (int argc,string argv[])
{
    if(argc!=2)
    {
        printf("invalid input\n");
        return 1;
    }
    string k=argv[1];
    int n=strlen(k);
    for(int i=0;i<n;i++)
    { if(!isalpha(k[i]))
    {
        printf("invalid input\n");
        return 1;
    }
    }
    printf("plaintext:");
    string s=get_string();
    int d=0;
    int r=strlen(s);
    printf("ciphertext:");
    for(int j=0;j<r;j++)
    {
        if(isupper(s[j]))
        {  
            s[j]=(((s[j]-65)+con(d,k))%26)+65;
            printf("%c",s[j]);
            d++;}
            else if(islower(s[j]))
            {
                s[j]=(((s[j]-97)+con(d,k))%26)+97;
                printf("%c",s[j]);
            d++;}
            else printf("%c",s[j]);
    }
    printf("\n");
    return 0;
}
int con(int a,string k)
{
    int len=strlen(k);
    return tolower(k[a%len])-97;
}

            