/**
 * helpers.c
 *
 * Helper functions for Problem Set 3.
 */
 
#include<cs50.h>

#include "helpers.h"

/**
 * Returns true if value is in array of n values, else false.
 */
bool search(int value, int values[], int n)
{   
   int str=0;
   int end=n-1;
   while(str<=end)
   {
       int m=(str+end)/2;
       if(value==values[m])
       { return true;
       }
       else if(value>values[m])
       str=m+1;
       else
       {end=m-1;}
   }
    return false;
}

/**
 * Sorts array of n values.
 */
void sort(int values[], int n)
{
    for(int i=0;i<n-1;i++)
    {
        for(int j=i;j<n-1;j++)
        {
            if(values[j]>values[j+1])
            {
                int temp=values[j];
                values[j]=values[j+1];
                values[j+1]=temp;
            }
        }
    }
}
            
        
    
   

